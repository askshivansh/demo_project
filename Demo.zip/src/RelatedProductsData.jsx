const sdata = [
    {
        sname: 'Embroidered baguette bag',
        imgsrc: 'https://i.ibb.co/nbyPY0d/Background-3.png',
        title: 'A Netflix Original Series',
        links: './',
        price: '$130'
    },
    {
        sname: 'Lace-up leather boots',
        imgsrc: 'https://i.ibb.co/XY2B6wT/Background-2.png',
        title: 'A Netflix Original Series',
        links: './',
        price: '$780'
    },
    {
        sname: 'Link chain necklace',
        imgsrc: 'https://i.ibb.co/sqmKkRn/Background-1.png',
        title: 'A Netflix Original Series',
        links: './',
        price: '$370'
    },
    {
        sname: 'Long sleeve lyocell t-shirt',
        imgsrc: 'https://i.ibb.co/BzHYSvt/Background.png',
        title: 'A Netflix Original Series',
        links: './',
        price: '$460'
    }
]

export default sdata;